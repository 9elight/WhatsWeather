package com.delight.whatsweather.data.remote

import com.delight.whatsweather.model.onecall.WeatherOneCall
import com.delight.whatsweather.model.weatherModel.CurrentWeather


class WeatherRepositories(private val weatherService: WeatherService) {
    suspend fun getWeather(city:String,format: String) : CurrentWeather {
        return weatherService.currentWeatherAsync(city, format)
    }
    suspend fun getOneCallWeather(lat: Double,lon:Double,lang: String,format: String): WeatherOneCall {
        return weatherService.oneCallWeather(lat, lon, format, lang)
    }
}