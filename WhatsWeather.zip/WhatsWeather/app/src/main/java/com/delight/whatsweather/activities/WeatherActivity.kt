package com.delight.whatsweather.activities

import android.app.FragmentTransaction
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.view.animation.Animation
import com.arellomobile.mvp.MvpActivity
import com.delight.whatsweather.R
import com.delight.whatsweather.data.remote.WeatherRepositories
import com.delight.whatsweather.fragments.DetailFragment
import com.delight.whatsweather.fragments.WeatherFragment
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import org.koin.android.ext.android.inject
import kotlin.coroutines.CoroutineContext

class WeatherActivity() : MvpActivity(),  CoroutineScope{
    private val weatherRepositories: WeatherRepositories by inject()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        openWeatherFragment()
        line1.setOnClickListener {
            openDetailFragment()
        }
    }


    override val coroutineContext: CoroutineContext
        get() = Dispatchers.Main


    private fun openWeatherFragment() {
        fragmentManager.beginTransaction().add(R.id.container_weather,WeatherFragment.instance()).commit()
    }

    private fun openDetailFragment(){
        val fragment = DetailFragment.instance()
        fragmentManager.beginTransaction()
            .setCustomAnimations(FragmentTransaction.TRANSIT_ENTER_MASK,FragmentTransaction.TRANSIT_EXIT_MASK)
            .add(R.id.container_detail,fragment).commit()
        container_detail.visibility = View.VISIBLE
    }

}
