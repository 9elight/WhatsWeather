package com.delight.whatsweather.views

import com.arellomobile.mvp.MvpView
import com.arellomobile.mvp.viewstate.strategy.OneExecutionStateStrategy
import com.arellomobile.mvp.viewstate.strategy.StateStrategyType
import com.delight.whatsweather.model.weatherModel.CurrentWeather

@StateStrategyType(value = OneExecutionStateStrategy::class)
interface WeatherView: MvpView{
    fun startWeatherLoading()
    fun endWeatherLoading()
    fun showWeather(weather: CurrentWeather?)
    fun showError(massage: String?)
}