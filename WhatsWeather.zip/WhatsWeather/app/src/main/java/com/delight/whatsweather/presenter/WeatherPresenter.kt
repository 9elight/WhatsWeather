package com.delight.whatsweather.presenter

import android.util.Log
import com.arellomobile.mvp.InjectViewState
import com.arellomobile.mvp.MvpPresenter
import com.delight.whatsweather.data.remote.WeatherRepositories
import com.delight.whatsweather.model.weatherModel.CurrentWeather
import com.delight.whatsweather.views.WeatherView
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

@InjectViewState
class WeatherPresenter(private val weatherRepositories: WeatherRepositories) :
    MvpPresenter<WeatherView>() {

    suspend fun loadWeather(city: String, format: String) {
        viewState.startWeatherLoading()
        val currentWeather = weatherRepositories.getWeather(city, format)
        val oneCall = weatherRepositories.getOneCallWeather(60.9,30.9,"ru","metric")
        viewState.showWeather(currentWeather)
        viewState.endWeatherLoading()
    }

}