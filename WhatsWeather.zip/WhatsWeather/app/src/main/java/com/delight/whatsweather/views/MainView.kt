package com.delight.whatsweather.views

interface MainView {
    fun openWeatherFragment()
}