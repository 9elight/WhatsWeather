package com.delight.whatsweather.fragments

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import com.arellomobile.mvp.MvpFragment
import com.arellomobile.mvp.presenter.InjectPresenter
import com.arellomobile.mvp.presenter.ProvidePresenter

import com.delight.whatsweather.R
import com.delight.whatsweather.data.remote.WeatherRepositories
import com.delight.whatsweather.model.weatherModel.CurrentWeather
import com.delight.whatsweather.presenter.WeatherPresenter
import com.delight.whatsweather.views.WeatherView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.koin.android.ext.android.inject
import kotlin.coroutines.CoroutineContext


class WeatherFragment : MvpFragment(), WeatherView,CoroutineScope {

    private val weatherRepositories: WeatherRepositories by inject()
    @InjectPresenter
    lateinit var weatherPresenter: WeatherPresenter
    @ProvidePresenter
    fun provideWeatherPresenter(): WeatherPresenter{
        return WeatherPresenter(weatherRepositories = weatherRepositories)
    }
    companion object{
        fun instance(): WeatherFragment{
            return WeatherFragment()
        }
    }
    private lateinit var mView: View

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        mView = inflater.inflate(R.layout.fragment_main_weather, container, false)
        return mView
    }

    override fun onViewCreated(view: View?, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        launch {
            weatherPresenter.loadWeather("Bishkek","metric")
        }
    }

    override fun startWeatherLoading() {
        Toast.makeText(context,"startWeatherLoading", Toast.LENGTH_LONG).show()
        Log.e("tag","startWeatherLoading")

    }

    override fun endWeatherLoading() {
        Toast.makeText(context,"endWeatherLoading", Toast.LENGTH_LONG).show()
        Log.e("tag","endWeatherLoading")

    }

    override fun showWeather(weather: CurrentWeather?) {
        Toast.makeText(context,"showWeather", Toast.LENGTH_LONG).show()
        Log.e("tag","showWeather")
    }

    override fun showError(massage: String?) {
        Toast.makeText(context,"showError", Toast.LENGTH_LONG).show()
    }

    override val coroutineContext: CoroutineContext
        get() = Dispatchers.Main

}
